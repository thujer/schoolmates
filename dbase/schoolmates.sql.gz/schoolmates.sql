-- Adminer 4.1.0 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DELIMITER ;;

DROP PROCEDURE IF EXISTS `get_person`;;
CREATE PROCEDURE `get_person`(IN `inl_id_person` int(11) unsigned)
SELECT *
FROM person
WHERE id_person = inl_id_person;;

DROP PROCEDURE IF EXISTS `get_person_classmate`;;
CREATE PROCEDURE `get_person_classmate`(IN `inl_id_person` tinyint)
BEGIN

/* Spoluzaci z krouzku */
SELECT hgp.id_person,
       CONCAT(p.s_name, ' ', p.s_lastname) AS s_classmate_name,
       GROUP_CONCAT(hgp.id_hobby_group) AS id_hobby_group,
       GROUP_CONCAT(hg.s_name) AS s_hobby_group_name
FROM hobby_group_person hgp

LEFT JOIN hobby_group hg
ON hg.id_hobby_group = hgp.id_hobby_group

LEFT JOIN person p
ON p.id_person = hgp.id_person

WHERE hgp.id_person IN (
	SELECT hgp.id_hobby_group
	FROM hobby_group_person hgp
	WHERE hgp.id_person = inl_id_person

) AND NOT hgp.id_person = inl_id_person

GROUP BY p.id_person;

END;;

DROP PROCEDURE IF EXISTS `get_person_details`;;
CREATE PROCEDURE `get_person_details`(IN `inl_id_person` int(11) unsigned)
BEGIN

/* Seznam ID vsech zajmu dane osoby */
CREATE TEMPORARY TABLE hobby ENGINE=MEMORY AS (
	SELECT hgp.id_hobby_group
	FROM hobby_group_person hgp
	WHERE hgp.id_person = inl_id_person
);

SELECT p.*
FROM person p
WHERE p.id_person = inl_id_person;

/* Detaily zajmu dane osoby */
SELECT hg.*
FROM hobby h
LEFT JOIN hobby_group hg
ON hg.id_hobby_group = h.id_hobby_group;

/* Spoluzaci z krouzku */
SELECT hgp.id_person,
       hgp.id_hobby_group,
       hg.s_name
FROM hobby_group_person hgp
LEFT JOIN hobby_group hg
ON hg.id_hobby_group = hgp.id_hobby_group
WHERE hgp.id_person IN (SELECT * FROM hobby) AND NOT hgp.id_person = inl_id_person;

END;;

DROP PROCEDURE IF EXISTS `get_person_list`;;
CREATE PROCEDURE `get_person_list`()
BEGIN

SELECT p.*,
       GROUP_CONCAT(hg.s_name) AS hobby_group_name

FROM person p

LEFT JOIN hobby_group_person hgp
ON hgp.id_person = p.id_person

LEFT JOIN hobby_group hg
ON hgp.id_hobby_group = hg.id_hobby_group

GROUP BY p.id_person;

END;;

DELIMITER ;

DROP TABLE IF EXISTS `hobby_group`;
CREATE TABLE `hobby_group` (
  `id_hobby_group` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Číslo zájmového kroužku',
  `s_name` varchar(100) NOT NULL COMMENT 'Název zájmového kroužku',
  `s_glyphicon` varchar(100) NOT NULL COMMENT 'Ikona Bootstrap',
  PRIMARY KEY (`id_hobby_group`),
  UNIQUE KEY `id_hobby_group` (`id_hobby_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Zájmové kroužky';

INSERT INTO `hobby_group` (`id_hobby_group`, `s_name`, `s_glyphicon`) VALUES
(1,	'Ochránci přírody',	'glyphicon-tree-deciduous'),
(2,	'Kreslení',	'glyphicon-pencil'),
(3,	'Turistický kroužek',	'glyphicon-picture'),
(4,	'Fotografování',	'glyphicon-camera');

DROP TABLE IF EXISTS `hobby_group_person`;
CREATE TABLE `hobby_group_person` (
  `id_hobby_group` int(11) unsigned NOT NULL COMMENT 'Číslo zájmového kroužku',
  `id_person` int(11) unsigned NOT NULL COMMENT 'Číslo osoby',
  KEY `id_hobby_group` (`id_hobby_group`),
  KEY `id_person` (`id_person`),
  CONSTRAINT `hobby_group_person_ibfk_3` FOREIGN KEY (`id_hobby_group`) REFERENCES `hobby_group` (`id_hobby_group`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `hobby_group_person_ibfk_4` FOREIGN KEY (`id_person`) REFERENCES `person` (`id_person`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Přihlášení jedinci';

INSERT INTO `hobby_group_person` (`id_hobby_group`, `id_person`) VALUES
(1,	1),
(2,	3),
(2,	2),
(3,	3),
(3,	2),
(4,	3),
(3,	4),
(2,	1),
(4,	1);

DROP TABLE IF EXISTS `person`;
CREATE TABLE `person` (
  `id_person` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Číslo osoby',
  `s_name` varchar(100) NOT NULL COMMENT 'Jméno',
  `s_lastname` varchar(100) NOT NULL COMMENT 'Příjmení',
  `e_gender` enum('Neuvedeno','Muž','Žena') NOT NULL COMMENT 'Pohlaví',
  `nl_age` tinyint(3) unsigned NOT NULL COMMENT 'Věk',
  PRIMARY KEY (`id_person`),
  UNIQUE KEY `id_person` (`id_person`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Osoby';

INSERT INTO `person` (`id_person`, `s_name`, `s_lastname`, `e_gender`, `nl_age`) VALUES
(1,	'Magda',	'Hrušková',	'Žena',	8),
(2,	'Maruška',	'Vavřínová',	'Žena',	9),
(3,	'Jiří',	'Lebeda',	'Muž',	10),
(4,	'Váňa',	'Ivanov',	'Muž',	8),
(5,	'Vendula',	'Kubová',	'Žena',	11);

DROP TABLE IF EXISTS `person_preschool`;
CREATE TABLE `person_preschool` (
  `id_person` int(11) unsigned NOT NULL COMMENT 'Číslo osoby',
  `id_preschool` int(11) unsigned NOT NULL COMMENT 'Číslo školky',
  KEY `id_person` (`id_person`),
  KEY `id_preschool` (`id_preschool`),
  CONSTRAINT `person_preschool_ibfk_1` FOREIGN KEY (`id_person`) REFERENCES `person` (`id_person`),
  CONSTRAINT `person_preschool_ibfk_2` FOREIGN KEY (`id_preschool`) REFERENCES `preschool` (`id_preschool`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Děti na školkách';

INSERT INTO `person_preschool` (`id_person`, `id_preschool`) VALUES
(3,	1),
(2,	1),
(1,	2);

DROP TABLE IF EXISTS `preschool`;
CREATE TABLE `preschool` (
  `id_preschool` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Číslo školky',
  `s_name` varchar(100) NOT NULL COMMENT 'Název školky',
  PRIMARY KEY (`id_preschool`),
  UNIQUE KEY `id_preschool` (`id_preschool`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Školky';

INSERT INTO `preschool` (`id_preschool`, `s_name`) VALUES
(1,	'Mateřská školka V jahůdkách Praha'),
(2,	'Odborné kurzy IT');

-- 2014-10-01 07:26:15
